package com.example.hardwareapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
