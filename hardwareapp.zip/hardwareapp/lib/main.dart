import 'package:flutter/material.dart';
import 'package:hardwareapp/utils/constants/colors.dart';
import 'package:hardwareapp/utils/theme/theme.dart';

import 'app.dart';

void main() {

  TColors.linearGradien
  runApp(const App());
}


